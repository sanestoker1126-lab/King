POCHECHE - ATLAS MAESTRO
========================
Frames personaje: 104
Frames FX morado/carmesí: 43
Celda: 256x256 RGBA
Pivot personaje: bottom_center
Padding mínimo: 8 px
Extrusión RGB: 2 px
Escala: uniforme X=Y
Fuentes rechazadas previamente por el usuario: NO incluidas.

Archivos:
- POCHECHE_ATLAS_MASTER.png/json/csv
- POCHECHE_FX_PURPURA_CARMESI.png/json/csv
- frames/ (PNG individuales)
- fx_frames/ (PNG FX individuales)
- rejected/ (componentes ambiguos o pegados)
- QA_REPORT.json
